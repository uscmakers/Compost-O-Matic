This is a library for our optical Fingerprint sensor

  Pick one up today in the adafruit shop!
  ------> http://www.adafruit.com/products/751

These displays use TTL Serial to communicate, 2 pins are required to  
interface

Adafruit invests time and resources providing this open source code, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Written by Limor Fried/Ladyada  for Adafruit Industries.  
BSD license, check license.txt for more information
All text above must be included in any redistribution

!!! Update for Particle Libraries V2.0, Jan 2016 !!!
!!! Adapted for Spark Core by Paul Kourany, May 2014 !!!
